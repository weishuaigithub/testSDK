//
//  PICallBackType.h
//  SGMSDKPa
//
//  Created by weishuai on 2025/2/21.
//

//修改了枚举值
//该值根据方法计算得得来 ，参考方法类："PICallBackTypeValue.h"
typedef NS_ENUM(NSUInteger, PICallBackType) {
    CallBack_START_FAIL_QUERY =  4224,  // StartFailQuery
    CallBack_GET_CAR_STATUS = 4480,  // GetCarStatus
    CallBack_FOB_STATUS = 1664,  // FobStatus
    CallBack_SET_PERSONAL_NOTIFY = 640 ,  // SetPersonalNotify
    CallBack_STOP_CMD = 896,  // StopCmd
    CallBack_CONNECT = -1,  // Connect
    CallBack_TERMINATE = -2,  // Terminate
    CallBack_SEND_SRP_CMD = 8832,  // SendSrpCmd
    CallBack_CLIMATE_CTRL = 4995,     // CLIMATE CTRL 空调
    CallBack_SUPER_GREET_CMD = 4993,     // Super Greet 超级迎宾
    CallBack_SEND_0203 = 770,
    CallBack_SEND_0204 = 1026 ,
   
};
