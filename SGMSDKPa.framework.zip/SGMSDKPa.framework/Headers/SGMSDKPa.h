//
//  SGMSDKPa.h
//  SGMSDKPa
//
//  Created by dylan.xuw on 2023/8/25.
//

#import <Foundation/Foundation.h>
#import <SGMSDKPa/ListenerPa.h>
#import <SGMSDKPa/SGMSDKManagerPa.h>

//! Project version number for SGMSDKPa.
FOUNDATION_EXPORT double SGMSDKPaVersionNumber;

//! Project version string for SGMSDKPa.
FOUNDATION_EXPORT const unsigned char SGMSDKPaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SGMSDKPa/PublicHeader.h>


