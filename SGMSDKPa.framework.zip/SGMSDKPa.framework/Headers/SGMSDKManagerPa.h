//
//  SGMSDKManagerPa.h
//  SGMSDK
//
//  Created by wenfu.xu on 2023/08/30.
//

#import <Foundation/Foundation.h>
//#import <SGMSDK/SGMSDK.h>
#import <SGMSDKPa/ListenerPa.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^ResponseSuccessPa) (__nullable id responseObject);
typedef void (^ResponseFailedPa) (NSError *__nullable error);
/**
 * ibeacon拉活回调
 */
typedef void (^ibeaconToAPPCallBackPa) (NSString * _Nullable vin,DKIBeaconStatePa ibeaconEvent,UIApplicationState appState);

@protocol SGMSDKReturnMessageDelegatePa <NSObject>

/**
 * 将命令通知给app
 */
- (void)setStatusListenerDelegate:(ListenerPa *)listener;

/**
 * 通知给车端APA数据
 */
- (void)sgmVKMToSDKAPAData:(NSString *)apaDataString;

@end

@interface SGMSDKManagerPa : NSObject

@property(nonatomic,weak) id<SGMSDKReturnMessageDelegatePa> delegate;

+ (SGMSDKManagerPa *)sharedInstance;
/** 白盒初始化
 * @param success 成功返回的数据
 * @param failure 失败返回的数据
 * MARK:白盒初始化
 */
//-(void)initWithWhiteBoxSuccess:(ResponseSuccess)success Failure:(ResponseFailed)failure;
/**
 * 拿到数字证书调用 保存数据到数据库
 * @param bleVersion           ble版本 16进制字符串
 * @param vkId                         VK编号 16进制字符串
 * @param vk                     虚拟钥匙  16进制字符串
 * @param csk                                     C-SK  16进制字符串
 * @param sha256          SHA256  16进制字符串
 * @param guid                        guid （GUID） 16进制字符串
 * @param vin                                     车辆VIN号 16进制字符串
 * @param validTime  授权时段 16进制字符串
 * @param cardATC    计数器 16进制字符串 4个字节
 * @param calibration   手机一致性标定数据
 */
- (void)addCarKeyBLEVersion:(NSString *)bleVersion vkId:(NSString *)vkId vk:(NSString *)vk csk:(NSString *)csk sha256:(NSString *)sha256 guid:(NSString *)guid vin:(NSString *)vin validTime:(NSString *)validTime cardATC:(NSString *)cardATC calibration:(NSString *)calibration success:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;
/**
 * 查询全部钥匙信息
 */
- (void)getCarkeyIDListSuccess:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;
/**
 * 查询某一条钥匙信息
 * @param vkId                                     VK编号 16进制字符串
 */
- (void)readCarkey:(NSString *)vkId success:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;
/**
 * 打印调试日志
 * @param debugLog                                     BOOL值
 */
- (void)sgmSetDebugLog:(BOOL)debugLog;
/**
 * 连接某一个蓝牙
 * @param vkId                                     VK编号 16进制字符串
 */
- (void)connect:(NSString *)vkId success:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;
/**
 获取车辆是否在附近
 @param vin                                     VIN码
 */
- (void)getWhetherTheVehicleIsNearby:(NSString *)vin success:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;
/**
 判断是否连接设备
 @param vin                                     VIN码
 */
- (BOOL)whetherToConnect:(NSString *)vin;
/**
 * 设置蓝牙扫描是否一直开启 默认开启
 */
- (void)scanIsRetry:(BOOL)retry;
/**
 * 停止扫描
 */
- (void)stopScan;
/**
 * 断开蓝牙
 */
- (void)terminate;
/**
 * 查询sdk版本号
 */
- (NSString *)getSDKversion;
/**
 * SDK提供本机标识DUID
 */
- (NSString *)getPhoneDUID;
/**
 * 获取手机型号
 */
- (NSString *)getMobilePhoneModel;
/**
 * 通用控制命令
 * @param functionCode                            控制命令码
 */
- (void)sendCmdFunctionCode:(SGMAPFUNCMDSPPa)functionCode success:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;
/**
  * 空调控制
 */
- (void)sendClimateControl:(FrontAC *)frontLeftAC rearLeftAC:(RearAC *)rearLeftAC resetAllAC:(WholeAC *)resetAllAC success:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;
/**
  * 超级迎宾
 */
- (void)superGreetCmd:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;



/*
 * 泛亚DEBUG接口END
 */
- (void)reqCarLog:(BOOL)enable;

/**
 * APA命令
 * @param functionCode                            控制命令码
 */
//- (void)sendAPAFunctionCode:(SGMBAPACommand)functionCode;
/**
 * 发送启动失败查询命令
 */
- (void)engineStartFailQuerySuccess:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;
/**
 * 手机发送的中止命令
 */
//- (void)AbortCountDown;
/**
 * 查询钥匙使能失能状态
 */
- (void)fobStatusSuccess:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;
/**
 * 查询整车状态命令
 */
- (void)getCarStatusSuccess:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;
/**
 * 创建日志
 */
- (void)createLogPath:(NSString *)pathString fileName:(NSString *)fileName;
/**
 * 获取SDK日志
 */
-(void)debugLog:(void (^)(NSString *))logBack;
/**
 * 拉活
 */
- (void)scanBeaconWithBLEMAC:(NSString *)vinString success:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;
/**
 * 停止拉活
 */
- (void)stopBeaconMonitor:(NSString *)vinString;
/**
 * 获取定位权限
 */
- (BOOL)checkLocationAuth;
/**
 * ibeacon 事件 通知 app ，状态改变时/亮屏，以及应用启动时会进入该回调
 * @param callback  ibeacon事件回调
 */
-(void)iBeaconMonitorToAPPCallBack: (ibeaconToAPPCallBackPa) callback;
/**
 * 获取BLE MAC地址
 */
- (void)getBLEMac:(NSString *)vkId success:(ResponseSuccessPa)success;
/**
 * 个性化设置通知，手机拿到手机状态以后需要传给sdk
 * @param theKeyBinding    虚拟钥匙和物理钥匙绑定关系 00 无绑定  01 绑定一号钥匙   02 绑定2号钥匙    03 其他数据（VKM不做透传）
 * @param welcomeTheLamp    迎宾灯使能设置  00 Disabled   01 Enabled     02 其他数据（VKM不做透传）
 * @param autoSign         Auto Sign 使能设置   00 Disabled   01 Enabled    02 其他数据（VKM不做透传）
 * @param thePhysicalKey        物理钥匙使能使能设置   00 Disabled   01 Enabled   02 其他数据（VKM不做透传）
 * @param nfcStates        NFC卡状态 458车型传FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF（SDK收到此数据不会传给VKM）
                        BEV3车型 传NFC卡的状态 00 no action 01 resume 02 suspended   必须：01020000格式类型
 * @param leaveTheCarAndLock         离车落锁功能   00 Disabled   01 Enabled   02 其他数据（VKM不做透传）
 * @param fobMACAndState         FOB钥匙MAC及State状态   00 invalid/default   01 valid   02 suspend  03~FF:reserved
 */
- (void)personalizationNotificationAboutTheKeyBinding:(NSString *)theKeyBinding welcomeTheLamp:(NSString *)welcomeTheLamp autoSign:(NSString *)autoSign thePhysicalKey:(NSString *)thePhysicalKey nfcStates:(NSString *)nfcStates leaveTheCarAndLock:(NSString *)leaveTheCarAndLock fobMACAndState:(NSString *)fobMACAndState success:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;
/**
 * 行程类车控停止指令
 */
- (void)travelTypeCarControlStopInstruction:(SGMAPFUNCMDSPPa)functionCode success:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;

/**
 SRP command 不带滚码
 @param command   SGMBSRPCommand类型命令
 @param modelSelection   kSGMTestModel 测试车型   kSGMFormalModel  正式车型
 */
- (void)srpSupervisedRemoteParkingComnand:(SGMBSRPCommandPa)command modelSelection:(SGMAPAModelSelectionPa)modelSelection failed:(ResponseFailedPa)failed;
/**
 * SRP command
 * @param command   SGMBSRPCommand类型命令
 * @param rollTheCode   滚码 0/1/2/3
 * @param allMd5   command与滚码拼接做md5加密（01+00）
 * @param modelSelection   kSGMTestModel 测试车型   kSGMFormalModel  正式车型
 */
- (void)srpSupervisedRemoteParkingComnand:(SGMBSRPCommandPa)command rollTheCode:(NSInteger)rollTheCode allMd5:(NSString *)allMd5 modelSelection:(SGMAPAModelSelectionPa)modelSelection failed:(ResponseFailedPa)failed;
/**
 * SRP Button Mobile Status
 * @param crossBackInSoft         0 Not_pressed  1 Pressed     Supervised Remote Parking Cross Back-In Soft Button Mobile Status
 * @param leftSoft                0 Not_pressed  1 Pressed     Supervised Remote Parking Left Soft Button Mobile Status
 * @param parallelParkingSoft     0 Not_pressed  1 Pressed     Supervised Remote Parking Parallel Parking Soft Button Mobile Status
 * @param rightSoft               0 Not_pressed  1 Pressed     Supervised Remote Parking Right Soft Button Mobile Status
 * @param exitParkSoft            0 Not_pressed  1 Pressed     Supervised Remote Parking Exit Park Soft Button Mobile Status
 * @param searchingSoft           0 Not_pressed  1 Pressed     Supervised Remote Parking Searching Soft Button Mobile Status
 * @param crossFrontInSoft        0 Not_pressed  1 Pressed     Supervised Remote Parking Cross Front-In Soft Button Mobile Status
 * @param exploreModeSoft         0 Not_pressed  1 Pressed     Supervised Remote Parking Explore Mode Soft Button Mobile Device Status
 */
- (void)srpButtonMobileStatusCrossBackInSoft:(NSInteger)crossBackInSoft leftSoft:(NSInteger)leftSoft parallelParkingSoft:(NSInteger)parallelParkingSoft rightSoft:(NSInteger)rightSoft exitParkSoft:(NSInteger)exitParkSoft searchingSoft:(NSInteger)searchingSoft crossFrontInSoft:(NSInteger)crossFrontInSoft exploreModeSoft:(NSInteger)exploreModeSoft;

/**
 * SRP Mobile Deactivation Button Status
 * @param mobileDeactivation  0 Not_pressed     1  exception Pressed  2 normal pressed
 */
- (void)srpMobileDeactivationButtonStatus:(NSInteger)mobileDeactivation;
/**
 * 仅测试使用 不能传入空
 * @param vinName   VIN码
 */
- (NSString *)backVKMName:(NSString *)vinName;

/// 更新本地一致性参数
/// @param calibration 一致性参数
/// @param vkId vkId
- (BOOL)updateCalibration:(NSString *)calibration byVKId:(NSString *)vkId;

/**
 * 停止SRP车控命令
 */
//- (void)stopSRPCommand;
/**
 *删除除保留的日志
 *@param fileNum 保留前几天
 */
//-(void)deleteLogFile:(NSInteger)fileNum;
/**
 * 是否开启日志模式 默认开启
 */
//-(void)setDebug:(BOOL)debug;
/**
 *获取目录下所有文件
 */
//-(NSArray *)getPath;
/**
 * #warning 连接蓝牙测试连接设备
 */
//- (void)connectToPeripheral:(CBPeripheral *)peripheral;

#ifdef ISSEC_MACRO

- (void)switchSDKSelection:(SGMIBeaconSelectionPa)sdkSelection;
/**
 * 设置本地Duid
 * @param newDuid                                   NSString类型
 */
- (BOOL)saveDuid:(NSString *)newDuid;
/**
 * 设置本地环境
 * @param debug  BOOL值
 */
- (void)sgmSetIsLocalEnviroment:(BOOL)debug;

/**
 * 根据vin号数据库中删除钥匙
 * @param vkId                                     VK编号 16进制字符串
 */
- (void)deleteCarKeyWithVkId:(NSString *)vkId success:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;
/**
  * 添加钥匙列表
  * @param carKeyList 钥匙列表，Json String格式
  * @param success 成功回调block
  * @param failure 失败回调block
  */
- (void)addCarKeyList:(NSArray<NSString *> *)carKeyList success:(ResponseSuccessPa)success failure:(ResponseFailedPa)failure;

#endif

@end

NS_ASSUME_NONNULL_END
