//
//  ListenerPa.h
//  SGMSDK
//
//  Created by wenfu.xu on 2023/08/30.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


typedef enum {
    BLE_DISCONNECT_Pa,         //蓝牙断连
    BLE_CONNECTED_Pa,          //蓝牙已经连接
    BLE_OPEN_Pa,               //蓝牙开启
    BLE_CLOSE_Pa,              //蓝牙关闭
    BLE_START_SCAN_Pa,         //开始扫描
    BLE_AUTH_SUCCESS_Pa,       //认证成功
    BLE_AUTH_FAIL_Pa,          //认证未通过
    BLE_Pair_Pa,               //配对中
    BLE_Positioning_Pa,        //正在定位
    BLE_Restricte_Pa,          //未授权
    BLE_AUTH_WaitFor_Pa,       //正在认证
    ERROR_VK_CANCEL_Pa,        //钥匙中止
    ERROR_CONNECT_TIMEOUT_Pa,  //连接设备超时
    TEST_VALUE_91 = 91,     //TEST
    TEST_VALUE_92 = 92,
}
StatusBLETypePa;


//车控指令
typedef NS_ENUM(NSInteger,SGMAPFUNCMDSPPa){
//    NoActivationPa,                                                     //无活动
    AllDoorsLockPa = 1,                                                 //整车上锁—>EC
    DriverUnlockPa,                                                     //仅解锁主驾门—>EC
    AllDoorsUnlockPa,                                                   //解锁所有车门—>EC
    PowerRearClosureControlOpenPa,                                      //电动尾门开—>PLG
    LeftSlidingDoorControlPa,                                           //左滑移门控制—>PSD
    RightSlidingDoorControlPa,                                          //右滑移门控制—>PSD
    PanicAlarmControlOpenPa,                                            //报警—>EC
    RVSEngineRunPa = 11,                                                //遥控启动—>RVS
    RVSEngineStopPa,                                                    //遥控启动熄火—>RVS
    EngineEnterReadyStatusPa,                                           //车辆进入可启动状态—>VKM
    LocateAlarmControlPa,                                               //寻车功能—>EC
//    FrontClosureControlReleasePa,                                       //电动前备箱解锁—>EC
    SunroofControlVentPa = 18,                                          //天窗通风
    EngineExitReadyStatusPa = 19,                                       //车辆退出可启动功能—>VKM
    PanicAlarmControlCancelPa = 26,                                     //停止报警鸣笛
    ComfortOpen2Pa,                                                     //一键升窗控制（窗）—>PW
    ComfortClose2Pa,                                                    //一键降窗控制（窗）—>PW
    LeftSlidingDoorControlStopPa,                                       //暂停左侧滑移门动作
    RightSlidingDoorControlStopPa = 47,                                 //暂停右侧滑移门动作
//    SuperGreetPa = 50,                                                  //超级迎宾灯功能
    FrontLeftPowerDoorControlStartPa = 62,                               //左前电动侧开门动作启动
    FrontRightPowerDoorControlStartPa = 63,                              //右前电动侧开门动作启动
    FrontLeftPowerDoorControlStopPa = 112,                               //左前电动侧开门动作暂停
    FrontRightPowerDoorControlStopPa = 113,                              //右前电动侧开门动作暂停
//    PowerRearClosureControlClosePa = 116,                               //电动尾门关—>PLG
    RearClosureControlUnlockPa = 117,                                         //后备箱解锁—>EC
    RearClosureControlReleasePa,                                        //电动后备箱解锁—>EC
    PowerRearClosureControlCancelPa,                                    //电动尾门暂停—>PLG
//    PowerfrontClosureControlOpenPa,                                     //电动前门开—>PLG
//    PowerfrontClosureControlClosePa,                                    //电动前门关—>PLG
//    PowerfrontClosureControlCancelPa,                                   //电动前门暂停—>PLG
    LocateAlarmControlMidPa = 123,                                            //寻车功能-mid—>EC
    LocateAlarmControlHighPa,                                           //寻车功能-high—>EC
    LocateAlarmControlCancelPa,                                         //寻车功能-cancel—>EC
    SunRoofcontrolOpenPa,                                               //天窗开-sunroof
    SunRoofControlClosePa,                                              //天窗关-sunrool
    OpenWindowsAndRearviewMirrorsPa,                                  //开车窗和展开后视镜
    CloseTheWindowsAndFoldTheRearviewMirrorPa,                        //关车窗和折叠后视镜
    OpenWindowsAndSunroofPa,                                          //开车窗和天窗
    CloseTheWindowsAndSunroofPa,                                      //关车窗和天窗
    OpenTheRearViewMirrorWithTheSunroofFullyOpenPa,                   //全开车窗天窗展开后视镜
    FullyCloseWindowSunroofFoldingRearviewMirrorPa,                   //全关车窗天窗折叠后视镜
//    WelcomeLightDisablePa,                                              //迎宾灯功能关闭
//    FobEnablePa,                                                        //钥匙使能
//    FobDisablePa,                                                       //钥匙失能
//    AutoSignInEnablePa,                                                 //自动登录使能
//    AutoSignInDisablePa,                                                //自动登录失能
};

// SRP command
typedef NS_ENUM(NSInteger,SGMBSRPCommandPa){
    NoActionPa,
    InitiateParkingPa, //初始化泊车
    PauseParkingPa,    //暂停泊车
    ContinueParkingPa, //继续 、一直泊车中
    ResumeParkingPa,//458 恢复泊车
    ContinueUnparkingPa,//无定义 未使用
    ForwardMovePa,    //458  3帧之后 发3    233 一直发  前进移动
    BackwardMovePa,    //458  3帧之后 发3   233 一直发  后退移动
    PowerOffPa,//233    3帧之后 发0
    ExitManeuverPa,//233 3帧之后 发0
    Reserved10Pa,
    Reserved11Pa,
    Reserved12Pa,
    Reserved13Pa,
    Reserved14Pa,
    Reserved15Pa,
};


typedef NS_ENUM(NSUInteger, DKIBeaconStatePa) {
    DKIBeaconStateUnknownPa = 0,                  // 未知
    DKIBeaconStateInsidePa = 1,                   // 区域内
    DKIBeaconStateOutsidePa = 2,                  // 区域外
};


typedef enum {
    kSGMRiskEventUdidPa, //0
    kSGMRiskEventRootPa,
    kSGMRiskEventEmulatorPa,
    kSGMRiskEventInjectPa,
    kSGMRiskEventDebugPa,
    kSGMRiskEventHttpProxyPa,
    kSGMRiskEventRiskFramePa
} SGMRiskEventPa;

//APA车型选择

typedef NS_ENUM(NSInteger,SGMAPAModelSelectionPa){
//    kSGMTestModelPa,
//    kSGMFormalModelPa,
    kSGMModel233Pa,
    kSGMModel458Pa
};

#ifdef ISSEC_MACRO
typedef NS_ENUM(NSInteger,SGMIBeaconSelectionPa){
    kSGMIBeaconPatacPa = 0,
    kSGMIBeaconUaesPa
};
#endif

/** 指令返回 */
@interface CmdResponsePa : NSObject
/**
 * 0 success
 * 1 fail
 */
@property (nonatomic,assign)NSInteger result;
/**
 * 命令码
 */
@property (nonatomic,assign)SGMAPFUNCMDSPPa cmdType;
/**
 * 成功与失败描述
 */
@property (nonatomic,copy)NSString* msg;

- (instancetype)initWithCmdType:(SGMAPFUNCMDSPPa )cmdType Msg:(NSString *)msg;

@end





/** 其它返回信息 */
@interface CommonResponsePa : NSObject
/**
 * 1 认证结果并同步车辆数据 迎宾灯开启或者关闭
 * 2 周期通知    车辆定位
 * 3 还车结果
 * 4 车辆状态
 * 5 配对码
 * 6 手机遗忘车内
 * 7 电源模式监控，车辆控制异常请检修
 * 8 车辆VIN码错误，请维修蓝牙模块
 * 9 远程启动失败查询
 * 10 车辆电压低，请尽快充电
 * 11 APA反馈
 * 12 删除无效钥匙通知给app
 * 13 钥匙使能失能状态查询
 * 14 虚拟钥匙终止/暂停，请联系上汽通用服务部
 * 15 虚拟钥匙授权时间失效超过30分钟
 * 16 虚拟钥匙超期，GPS超时45分钟,断开连接
 * 17 虚拟钥匙撤销,断开连接
 * 18 检查数字钥匙有效期发现虚拟钥匙过期,断开连接
 * 19 低电压休眠模式,断开连接
 * 20 虚拟钥匙超期,RTC超时15分钟,断开连接
 * 21 虚拟钥匙失效,断开连接
 * 23 离车落锁功能触发
 */
@property (nonatomic,assign)NSInteger type;
/**
 *  msg 返回数据内容
 */
@property (nonatomic,strong)NSDictionary *msg;

- (instancetype)initWithType:(int32_t)type msg:(NSDictionary *)msg;

@end




/** 认证、蓝牙等状态返回 */
@interface StatusTypePa : NSObject
/**
 蓝牙相关的值
 */
@property (nonatomic, assign) NSInteger value;
/**
 描述
 */
@property (nonatomic, copy) NSString* msg;
/**
 枚举值
 */
@property (nonatomic, assign) StatusBLETypePa bleType;

@end


/** 白盒威胁感知返回*/
@interface ThreatPerceptionPa : NSObject
/**
 枚举值
 */
@property (nonatomic, assign) SGMRiskEventPa riskEventType;
/**
 *  data 返回数据内容
 */
@property (nonatomic,strong)NSDictionary *data;

@end



@interface ListenerPa : NSObject
/** 指令返回 */
@property (nonatomic, strong) CmdResponsePa *onCommand;
/** 其它返回信息 */
@property (nonatomic, strong) CommonResponsePa *commonResponse;
/** 认证、蓝牙等状态返回 */
@property (nonatomic, strong) StatusTypePa *onStatus;
/** 白盒威胁感知返回*/
@property (nonatomic, strong) ThreatPerceptionPa *threatPerception;

@end

/** 空调控制 */
@interface FrontAC : NSObject

@property (nonatomic, copy) NSString *airDistributionFrontLeft;//左前送风
@property (nonatomic, copy) NSString *compressorSetting;//压缩机
@property (nonatomic, copy) NSString *temperLevelFrontLeft;//左前温度
@property (nonatomic, copy) NSString *temperLevelFrontLeftActive;//
@property (nonatomic, copy) NSString *blowerLevelFront;//前区风量
@property (nonatomic, copy) NSString *blowerActive;//
@property (nonatomic, copy) NSString *frontAuto;//前区自动
@property (nonatomic, copy) NSString *temperLevelFrontRight;//右前温度
@property (nonatomic, copy) NSString *temperLevelFrontRightActive;//
@property (nonatomic, copy) NSString *frontHVACPowerSetting;//前区启动

- (NSString *)toString1;
- (NSString *)toString2;

@end

@interface RearAC : NSObject

@property (nonatomic, copy) NSString *airDistributionRearLeft;//左后送风
@property (nonatomic, copy) NSString *rearAuto;//后区自动
@property (nonatomic, copy) NSString *blowerLevelRear;//后区风量
@property (nonatomic, copy) NSString *blowerLevelRearActive;//
@property (nonatomic, copy) NSString *temperLevelRearLeft;//后区温度
@property (nonatomic, copy) NSString *temperLevelRearLeftActive;//
@property (nonatomic, copy) NSString *rearHVACPowerSetting;//后区启动

- (NSString *)toString;

@end

@interface WholeAC : NSObject

@property (nonatomic, copy) NSString *recirculationSetting;//循环模式
@property (nonatomic, copy) NSString *rearDefogSetting;//除雾
@property (nonatomic, copy) NSString *maxDefrost;//除霜
@property (nonatomic, copy) NSString *climateModelSetting;//空调模式
@property (nonatomic, copy) NSString *syncAllSetting;//全车同步

- (NSString *)toString1;
- (NSString *)toString2;

@end

NS_ASSUME_NONNULL_END
